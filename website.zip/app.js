// Passenger-compatible entry point (CommonJS)
const express = require('express');
const path = require('path');

const app = express();

// Serve static files from the production build (Vite output)
const distDir = path.join(__dirname, 'dist');
app.use(express.static(distDir));

// SPA fallback — serve index.html for unmatched routes
app.get('*', (req, res) => {
  res.sendFile(path.join(distDir, 'index.html'));
});

module.exports = app;
