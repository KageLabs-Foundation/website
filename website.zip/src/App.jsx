import React, { useState, useEffect, useRef, createContext } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';

import HomePage from './components/HomePage/HomePage';
import KageAI from './components/KageAI/KageAI';
import KageAIChat from './components/KageAI/Chat/Chat';

import KageStudy from './components/KageStudy/KageStudy';
import Dashboard from './components/KageStudy/Dashboard/Dashboard';
import ToolsHome from './components/KageStudy/Dashboard/tools/ToolsHome';
import StudyChat from './components/KageStudy/Dashboard/tools/StudyChat';
import Exam from './components/KageStudy/Dashboard/tools/Exam';
import Flashcards from './components/KageStudy/Dashboard/tools/Flashcards';
import Notes from './components/KageStudy/Dashboard/tools/Notes';
import Planner from './components/KageStudy/Dashboard/tools/Planner';
import Summarizer from './components/KageStudy/Dashboard/tools/Summarizer';

import './App.css';

/* ===============================
   THEME CONTEXT
   =============================== */

export const ThemeContext = createContext();

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    const saved = localStorage.getItem('kagelabs-theme') || 'dark';
    setTheme(saved);
    document.documentElement.setAttribute('data-theme', saved);
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('kagelabs-theme', next);
    document.documentElement.setAttribute('data-theme', next);
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

/* ===============================
   ROUTE ACCENT MANAGER
   =============================== */

function RouteAccentManager() {
  const location = useLocation();

  useEffect(() => {
    document.body.classList.remove('route-kageai', 'route-kagestudy');

    if (location.pathname.startsWith('/kageai')) {
      document.body.classList.add('route-kageai');
    } else if (location.pathname.startsWith('/kagestudy')) {
      document.body.classList.add('route-kagestudy');
    }
  }, [location.pathname]);

  return null;
}

/* ===============================
   CURSOR FOLLOWER
   =============================== */

function CursorFollower() {
  const location = useLocation();

  // ❗ Hide cursor on ALL chat + dashboard + tools pages
  if (
    location.pathname.startsWith('/kageai/chat') ||
    location.pathname.startsWith('/kagestudy')
  ) {
    return null;
  }

  const followerRef = useRef(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const rafRef = useRef(null);

  useEffect(() => {
    const handleMove = (e) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };

      if (!rafRef.current) {
        rafRef.current = requestAnimationFrame(() => {
          if (followerRef.current) {
            followerRef.current.style.transform =
              `translate3d(${mouseRef.current.x - 12}px, ${mouseRef.current.y - 12}px, 0)`;
          }
          rafRef.current = null;
        });
      }
    };

    window.addEventListener('mousemove', handleMove);
    return () => {
      window.removeEventListener('mousemove', handleMove);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <div ref={followerRef} className="cursor-follower" />;
}

/* ===============================
   ANIMATED ROUTES
   =============================== */

function AnimatedRoutes() {
  const location = useLocation();
  const [displayLocation, setDisplayLocation] = useState(location);
  const [stage, setStage] = useState('fadeIn');

  useEffect(() => {
    if (location.pathname !== displayLocation.pathname) {
      setStage('fadeOut');
    }
  }, [location, displayLocation]);

  return (
    <div
      className={`route-container ${stage}`}
      onAnimationEnd={() => {
        if (stage === 'fadeOut') {
          setStage('fadeIn');
          setDisplayLocation(location);
        }
      }}
    >
      <Routes location={displayLocation} key={displayLocation.pathname}>
        <Route path="/" element={<HomePage />} />

        <Route path="/kageai" element={<KageAI />} />
        <Route path="/kageai/chat" element={<KageAIChat />} />

        <Route path="/kagestudy" element={<KageStudy />} />
        <Route path="/kagestudy/dashboard" element={<Dashboard />} />

        <Route path="/kagestudy/tools" element={<ToolsHome />} />
        <Route path="/kagestudy/tools/chat" element={<StudyChat />} />
        <Route path="/kagestudy/tools/notes" element={<Notes />} />
        <Route path="/kagestudy/tools/summarizer" element={<Summarizer />} />
        <Route path="/kagestudy/tools/flashcards" element={<Flashcards />} />
        <Route path="/kagestudy/tools/planner" element={<Planner />} />
        <Route path="/kagestudy/tools/exam" element={<Exam />} />
      </Routes>
    </div>
  );
}

/* ===============================
   MAIN APP
   =============================== */

function App() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => setLoaded(true), []);

  return (
    <ThemeProvider>
      <div className={`app ${loaded ? 'loaded' : ''}`}>
        <Router>
          <RouteAccentManager />
          <CursorFollower />
          <AnimatedRoutes />
        </Router>
      </div>
    </ThemeProvider>
  );
}

export default App;
