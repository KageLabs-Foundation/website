import React, { useState, useEffect, useRef, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, Menu, Save, Trash, X, Plug, 
  Sparkles, Target, User, Bot, Send,
  MoreVertical, Edit2, Archive, Trash2, ExternalLink,
  CheckSquare, FileText, Moon, Sun, Settings, Home,
  MessageSquare, Clock, Zap
} from 'lucide-react';
import { ThemeContext } from '../../../App';
import styles from './Chat.module.css';

// Backend API (Cloudflare Worker)
const API_URL = 'https://kageai-worker.playnav-yt.workers.dev';

const Chat = () => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [chats, setChats] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [isWaitingForResponse, setIsWaitingForResponse] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showIntegrationsModal, setShowIntegrationsModal] = useState(false);
  const [integrations, setIntegrations] = useState({});
  const [contextMenuChat, setContextMenuChat] = useState(null);
  const [editingChatId, setEditingChatId] = useState(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [userId] = useState('default_user');
  
  const chatAreaRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const savedChats = localStorage.getItem('kageai_chats');
    
    if (savedChats) {
      try {
        const parsedChats = JSON.parse(savedChats);
        setChats(parsedChats);
        if (parsedChats.length > 0) {
          setCurrentChatId(parsedChats[0].id);
        }
      } catch (error) {
        console.error('Error parsing saved chats:', error);
        createInitialChat();
      }
    } else {
      createInitialChat();
    }
  }, []);

  const createInitialChat = () => {
    const newChat = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
    };
    setChats([newChat]);
    setCurrentChatId(newChat.id);
  };

  useEffect(() => {
    loadIntegrationStatus();
    const interval = setInterval(() => {
      loadIntegrationStatus();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [userId]);

  const loadIntegrationStatus = async () => {
    try {
      const response = await fetch(`${API_URL}/api/integrations/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.status) {
          setIntegrations(data.status);
        }
      }
    } catch (error) {
      console.error('Error loading integration status:', error);
    }
  };

  useEffect(() => {
    if (chats.length > 0) {
      localStorage.setItem('kageai_chats', JSON.stringify(chats));
    }
  }, [chats]);

  useEffect(() => {
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [chats, currentChatId]);

  useEffect(() => {
    const handleClickOutside = () => {
      if (contextMenuChat) {
        setContextMenuChat(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [contextMenuChat]);

  const createNewChat = () => {
    const newChat = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
    };
    setChats(prev => [newChat, ...prev]);
    setCurrentChatId(newChat.id);
  };

  const switchToChat = (chatId) => {
    setCurrentChatId(chatId);
  };

  const deleteChat = (chatId) => {
    if (!window.confirm('Delete this chat?')) return;
    
    setChats(prev => {
      const filtered = prev.filter(c => c.id !== chatId && !c.archived);
      if (currentChatId === chatId && filtered.length > 0) {
        setCurrentChatId(filtered[0].id);
      }
      return filtered;
    });
    
    setContextMenuChat(null);
    
    if (chats.filter(c => !c.archived).length === 1) {
      createNewChat();
    }
  };

  const archiveChat = (chatId) => {
    setChats(prev => prev.map(chat => {
      if (chat.id === chatId) {
        return { ...chat, archived: true };
      }
      return chat;
    }));
    
    setContextMenuChat(null);
    
    if (currentChatId === chatId) {
      const activeChats = chats.filter(c => !c.archived && c.id !== chatId);
      if (activeChats.length > 0) {
        setCurrentChatId(activeChats[0].id);
      } else {
        createNewChat();
      }
    }
  };

  const startRenameChat = (chatId, currentTitle) => {
    setEditingChatId(chatId);
    setEditingTitle(currentTitle);
    setContextMenuChat(null);
  };

  const saveRenameChat = (chatId) => {
    if (editingTitle.trim()) {
      setChats(prev => prev.map(chat => {
        if (chat.id === chatId) {
          return { ...chat, title: editingTitle.trim() };
        }
        return chat;
      }));
    }
    setEditingChatId(null);
    setEditingTitle('');
  };

  const cancelRenameChat = () => {
    setEditingChatId(null);
    setEditingTitle('');
  };

  const addMessage = (content, isUser) => {
    setChats(prev => prev.map(chat => {
      if (chat.id === currentChatId) {
        const updatedMessages = [...chat.messages, {
          content,
          isUser,
          timestamp: new Date().toISOString(),
        }];
        
        let updatedTitle = chat.title;
        if (updatedMessages.length === 2 && isUser) {
          updatedTitle = content.substring(0, 30) + (content.length > 30 ? '...' : '');
        }
        
        return { ...chat, messages: updatedMessages, title: updatedTitle };
      }
      return chat;
    }));
  };

  const sendMessage = async () => {
    const message = messageInput.trim();
    if (!message || isWaitingForResponse) return;

    addMessage(message, true);
    setMessageInput('');
    setIsWaitingForResponse(true);

    try {
      const currentChat = chats.find(c => c.id === currentChatId);
      
      if (!currentChat) {
        addMessage('Error: Chat not found', false);
        setIsWaitingForResponse(false);
        return;
      }

      const history = currentChat.messages.slice(-10).map(msg => ({
        role: msg.isUser ? 'user' : 'assistant',
        content: msg.content
      }));

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, history, userId }),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        addMessage(data.response, false);
        
        if (data.metadata?.integrations) {
          setIntegrations(data.metadata.integrations);
        }
      } else {
        addMessage('Error: ' + (data.error || 'Unknown error'), false);
      }
    } catch (error) {
      console.error('Connection Error:', error);
      addMessage('Connection error. Make sure backend is running at ' + API_URL, false);
    } finally {
      setIsWaitingForResponse(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const sendSuggestion = (text) => {
    setMessageInput(text);
    setTimeout(() => {
      sendMessage();
    }, 100);
  };

  const exportCurrentChat = () => {
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat || chat.messages.length === 0) {
      alert('No messages to export');
      return;
    }

    const exportData = {
      title: chat.title,
      exported: new Date().toISOString(),
      messages: chat.messages
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kageai-${chat.title.replace(/\s+/g, '-')}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearCurrentChat = () => {
    if (!window.confirm('Clear all messages in this chat?')) return;
    
    setChats(prev => prev.map(chat => {
      if (chat.id === currentChatId) {
        return { ...chat, messages: [], title: 'New Chat' };
      }
      return chat;
    }));
  };

  const connectIntegration = async (integrationId) => {
    if (integrationId === 'todoist' || integrationId === 'notion') {
      const width = 600;
      const height = 700;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;
      
      const oauthUrl = `${API_URL}/api/integrations/${integrationId}/oauth/start?userId=${encodeURIComponent(userId)}`;
      
      const popup = window.open(
        oauthUrl,
        `${integrationId}OAuth`,
        `width=${width},height=${height},left=${left},top=${top}`
      );
      
      const pollTimer = setInterval(() => {
        if (popup && popup.closed) {
          clearInterval(pollTimer);
          setTimeout(() => {
            loadIntegrationStatus();
          }, 500);
        }
      }, 500);
      
      return;
    }
    
    alert(`${integrationId} integration coming soon!`);
  };

  const disconnectIntegration = async (integrationId) => {
    if (!window.confirm(`Disconnect ${integrationId}?`)) return;
    
    try {
      const response = await fetch(`${API_URL}/api/integrations/disconnect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, integration: integrationId }),
      });
      
      if (response.ok) {
        await loadIntegrationStatus();
      } else {
        alert('Failed to disconnect integration');
      }
    } catch (error) {
      console.error('Failed to disconnect:', error);
      alert('Failed to disconnect integration');
    }
  };

  const currentChat = chats.find(c => c.id === currentChatId);
  const hasMessages = currentChat && currentChat.messages.length > 0;

  const integrationsList = [
    { id: 'todoist', name: 'Todoist', desc: 'Create and manage tasks', Icon: CheckSquare },
    { id: 'notion', name: 'Notion', desc: 'Reference notes and pages', Icon: FileText },
  ];

  const suggestions = [
    { icon: Sparkles, title: 'Getting Started', desc: 'Learn about my capabilities', text: 'What can you help me with?' },
    { icon: CheckSquare, title: 'Create Tasks', desc: 'Add to your todo list', text: 'Create a task to review the project documentation' },
    { icon: Target, title: 'View Tasks', desc: 'See your todo list', text: 'What tasks do I have?' },
  ];

  const stats = [
    { label: 'Total Chats', value: chats.length, Icon: MessageSquare },
    { label: 'Today', value: chats.filter(c => {
      const today = new Date().toDateString();
      return new Date(c.createdAt).toDateString() === today;
    }).length, Icon: Clock },
    { label: 'Connected', value: Object.values(integrations).filter(Boolean).length, Icon: Zap }
  ];

  return (
    <div className={styles.container}>
      {/* Sidebar */}
      <aside className={`${styles.sidebar} ${sidebarCollapsed ? styles.collapsed : ''}`}>
        <div className={styles.sidebarHeader}>
          <div className={styles.logo}>
            <Bot size={28} />
            {!sidebarCollapsed && <span>KageAI</span>}
          </div>
          <button 
            className={styles.sidebarToggle}
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {sidebarCollapsed ? <Menu size={20} /> : <X size={20} />}
          </button>
        </div>

        <div className={styles.newChatSection}>
          <button className={styles.newChatBtn} onClick={createNewChat}>
            <Plus size={20} />
            {!sidebarCollapsed && <span>New Chat</span>}
          </button>
        </div>
        
        <div className={styles.chatList}>
          {chats.filter(c => !c.archived).map(chat => (
            <div
              key={chat.id}
              className={`${styles.chatItem} ${chat.id === currentChatId ? styles.active : ''}`}
              onClick={() => switchToChat(chat.id)}
            >
              {editingChatId === chat.id ? (
                <input
                  type="text"
                  value={editingTitle}
                  onChange={(e) => setEditingTitle(e.target.value)}
                  onBlur={() => saveRenameChat(chat.id)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') saveRenameChat(chat.id);
                    if (e.key === 'Escape') cancelRenameChat();
                  }}
                  className={styles.chatItemInput}
                  autoFocus
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <>
                  {!sidebarCollapsed && <MessageSquare size={16} className={styles.chatItemIcon} />}
                  <span className={styles.chatItemTitle}>{chat.title}</span>
                </>
              )}
              {!sidebarCollapsed && (
                <button
                  className={styles.chatItemMenu}
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    setContextMenuChat(contextMenuChat === chat.id ? null : chat.id);
                  }}
                >
                  <MoreVertical size={16} />
                </button>
              )}
              
              {contextMenuChat === chat.id && (
                <div className={styles.contextMenu} onClick={(e) => e.stopPropagation()}>
                  <button
                    className={styles.contextMenuItem}
                    onClick={() => startRenameChat(chat.id, chat.title)}
                  >
                    <Edit2 size={14} />
                    <span>Rename</span>
                  </button>
                  <button
                    className={styles.contextMenuItem}
                    onClick={() => archiveChat(chat.id)}
                  >
                    <Archive size={14} />
                    <span>Archive</span>
                  </button>
                  <button
                    className={`${styles.contextMenuItem} ${styles.danger}`}
                    onClick={() => deleteChat(chat.id)}
                  >
                    <Trash2 size={14} />
                    <span>Delete</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className={styles.sidebarFooter}>
          <button className={styles.navItem} onClick={() => setShowIntegrationsModal(true)}>
            <Plug size={20} />
            {!sidebarCollapsed && <span>Integrations</span>}
            {!sidebarCollapsed && Object.values(integrations).filter(Boolean).length > 0 && (
              <span className={styles.integrationBadge}>
                {Object.values(integrations).filter(Boolean).length}
              </span>
            )}
          </button>
          <button className={styles.navItem} onClick={() => navigate('/kageai')}>
            <Home size={20} />
            {!sidebarCollapsed && <span>Back to Home</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={styles.mainContent}>
        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>{currentChat?.title || 'KageAI'}</h1>
            <p className={styles.pageSubtitle}>AI-powered productivity assistant</p>
          </div>

          <div className={styles.topBarRight}>
            <button className={styles.topBarBtn} onClick={exportCurrentChat}>
              <Save size={18} />
              <span>Export</span>
            </button>
            <button className={styles.topBarBtn} onClick={clearCurrentChat}>
              <Trash size={18} />
              <span>Clear</span>
            </button>
            <button className={styles.themeToggle} onClick={toggleTheme}>
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </header>

        {/* Chat Area */}
        <div className={styles.chatArea} ref={chatAreaRef}>
          {!hasMessages ? (
            <div className={styles.emptyState}>
              <div className={styles.emptyLogo}>🤖</div>
              <h1 className={styles.emptyTitle}>Welcome to KageAI</h1>
              <p className={styles.emptySubtitle}>Your AI-powered productivity assistant</p>
              
              <div className={styles.suggestionsGrid}>
                {suggestions.map((suggestion, idx) => (
                  <div
                    key={idx}
                    className={styles.suggestionCard}
                    onClick={() => sendSuggestion(suggestion.text)}
                  >
                    <div className={styles.suggestionIcon}>
                      <suggestion.icon size={24} />
                    </div>
                    <div className={styles.suggestionTitle}>{suggestion.title}</div>
                    <div className={styles.suggestionDesc}>{suggestion.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <>
              {currentChat.messages.map((msg, idx) => (
                <div key={idx} className={`${styles.message} ${msg.isUser ? styles.userMessage : ''}`}>
                  <div className={`${styles.messageAvatar} ${msg.isUser ? styles.userAvatar : styles.aiAvatar}`}>
                    {msg.isUser ? <User size={20} /> : <Bot size={20} />}
                  </div>
                  <div className={styles.messageContent}>
                    {msg.content}
                  </div>
                </div>
              ))}
              
              {isWaitingForResponse && (
                <div className={styles.message}>
                  <div className={`${styles.messageAvatar} ${styles.aiAvatar}`}>
                    <Bot size={20} />
                  </div>
                  <div className={styles.messageContent}>
                    <div className={styles.typingIndicator}>
                      <div className={styles.typingDot}></div>
                      <div className={styles.typingDot}></div>
                      <div className={styles.typingDot}></div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Input Area */}
        <div className={styles.inputContainer}>
          <div className={styles.inputWrapper}>
            <div className={styles.inputArea}>
              <textarea
                ref={textareaRef}
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Message KageAI... (Press Enter to send, Shift+Enter for new line)"
                rows={1}
                disabled={isWaitingForResponse}
                className={styles.messageInput}
              />
              <button
                onClick={sendMessage}
                disabled={isWaitingForResponse || !messageInput.trim()}
                className={styles.sendButton}
              >
                <Send size={20} />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Integrations Modal */}
      {showIntegrationsModal && (
        <div className={styles.modal} onClick={() => setShowIntegrationsModal(false)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>Integrations</h2>
              <button className={styles.modalClose} onClick={() => setShowIntegrationsModal(false)}>
                <X size={24} />
              </button>
            </div>
            
            <div className={styles.integrationList}>
              {integrationsList.map(integration => {
                const isConnected = integrations[integration.id];
                return (
                  <div key={integration.id} className={styles.integrationItem}>
                    <div className={styles.integrationIcon}>
                      <integration.Icon size={32} />
                    </div>
                    <div className={styles.integrationInfo}>
                      <div className={styles.integrationName}>{integration.name}</div>
                      <div className={styles.integrationDesc}>{integration.desc}</div>
                    </div>
                    {isConnected ? (
                      <button
                        className={`${styles.integrationStatus} ${styles.connected}`}
                        onClick={() => disconnectIntegration(integration.id)}
                      >
                        Connected ✓
                      </button>
                    ) : (
                      <button
                        className={`${styles.integrationStatus} ${styles.disconnected}`}
                        onClick={() => connectIntegration(integration.id)}
                      >
                        Connect <ExternalLink size={14} style={{marginLeft: 4}} />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            
            <div className={styles.modalFooter}>
              <p className={styles.modalHint}>
                💡 Connected integrations enable the AI to create and manage your tasks
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chat;