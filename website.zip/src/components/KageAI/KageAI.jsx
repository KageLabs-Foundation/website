import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, Info, Play, ArrowRight, Bot, Mail, Calendar, Sparkles, Plug, User, Moon, Sun } from 'lucide-react';
import { ThemeContext } from '../../App';
import styles from './KageAI.module.css';

const KageAI = () => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [visible, setVisible] = useState({});

  useEffect(() => {
    // Scroll to top on mount
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      const sections = ['home', 'features', 'demo'];
      const newVisible = {};
      let newActive = 'home';

      sections.forEach(s => {
        const el = document.getElementById(s);
        if (el) {
          const r = el.getBoundingClientRect();
          const v = r.top < window.innerHeight * 0.75 && r.bottom > 0;
          newVisible[s] = v;

          if (r.top < window.innerHeight / 2 && r.bottom > window.innerHeight / 2) {
            newActive = s;
          }
        }
      });

      setVisible(prev => ({ ...prev, ...newVisible }));
      setActiveSection(prev => (prev !== newActive ? newActive : prev));
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const features = [
    {
      Icon: Bot,
      title: 'Smart Conversations',
      desc: 'Engage in natural, context-aware conversations with advanced AI that understands your needs and provides intelligent responses.'
    },
    {
      Icon: Mail,
      title: 'Email Integration',
      desc: 'Seamlessly connect with Gmail to read, summarize, and manage your emails with AI-powered assistance.'
    },
    {
      Icon: Calendar,
      title: 'Calendar Management',
      desc: 'Stay organized with intelligent calendar integration that helps you schedule and manage your time effectively.'
    },
    {
      Icon: Sparkles,
      title: 'Task Automation',
      desc: 'Automate repetitive tasks and workflows with AI-driven solutions that save you time and increase productivity.'
    },
    {
      Icon: Plug,
      title: 'Multiple Integrations',
      desc: 'Connect with your favorite tools including Slack, Notion, Todoist, and more for a unified workflow experience.'
    },
    {
      Icon: User,
      title: 'Secure & Private',
      desc: 'Your data is protected with enterprise-grade security and privacy measures, ensuring complete confidentiality.'
    }
  ];

  const handleSmoothScroll = (e, targetId) => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
        <div className={styles.headerContent}>
          <a href="/" className={styles.logoWrapper}>
            <div className={styles.logoGlow}></div>
            <div className={styles.logo}>KAGELABS</div>
          </a>
          
          <nav className={styles.nav}>
            <a
              href="#home"
              className={`${styles.navLink} ${activeSection === 'home' ? styles.active : ''}`}
              onClick={(e) => handleSmoothScroll(e, 'home')}
            >
              <Home size={18} />
              <span>Home</span>
            </a>
            <a
              href="#features"
              className={`${styles.navLink} ${activeSection === 'features' ? styles.active : ''}`}
              onClick={(e) => handleSmoothScroll(e, 'features')}
            >
              <Info size={18} />
              <span>Features</span>
            </a>
            <a
              href="#demo"
              className={`${styles.navLink} ${activeSection === 'demo' ? styles.active : ''}`}
              onClick={(e) => handleSmoothScroll(e, 'demo')}
            >
              <Play size={18} />
              <span>Demo</span>
            </a>
            <button className={styles.themeToggle} onClick={toggleTheme}>
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className={styles.hero}>
        <div className={styles.gridBackground}></div>
        <div className={`${styles.orb} ${styles.orbCyan}`}></div>
        <div className={`${styles.orb} ${styles.orbPurple}`}></div>
        
        <div className={styles.heroContent}>
          <div className={styles.heroBadge}>
            <span className={styles.heroBadgeText}>A KageLabs Innovation</span>
          </div>
          
          <h1 className={styles.heroTitle}>
            <span className={styles.heroTitleWord}>Your</span>{' '}
            <span className={`${styles.heroTitleWord} ${styles.heroTitleGradient}`} style={{ animationDelay: '0.1s' }}>
              AI-Powered
            </span>{' '}
            <span className={styles.heroTitleWord} style={{ animationDelay: '0.2s' }}>Assistant</span>
          </h1>
          
          <p className={styles.heroSubtitle}>
            KageAI combines cutting-edge artificial intelligence with seamless productivity tools to revolutionize how you work, communicate, and achieve your goals
          </p>
          
          <div className={styles.heroCTA}>
            <button className={styles.ctaPrimary} onClick={() => navigate('/kageai/chat')}>
              <span style={{ position: 'relative', zIndex: 10, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                Try KageAI Now
                <ArrowRight size={20} />
              </span>
              <div className={styles.ctaPrimaryOverlay}></div>
            </button>
            <a href="/" className={styles.ctaSecondary}>
              Explore KageLabs
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section 
        id="features" 
        className={`${styles.section} ${visible.features ? styles.visible : ''}`}
      >
        <div className={styles.sectionContent}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Powerful Features</h2>
            <div className={styles.sectionDivider}></div>
            <p className={styles.sectionSubtitle}>
              Experience the next generation of AI-powered productivity
            </p>
          </div>
          
          <div className={styles.featuresGrid}>
            {features.map((feature, index) => (
              <div key={index} className={styles.featureCard}>
                <div className={styles.featureCardGlow}></div>
                <div className={styles.featureCardContent}>
                  <div className={styles.featureIcon}>
                    <feature.Icon size={32} strokeWidth={2} />
                  </div>
                  <h3 className={styles.featureTitle}>{feature.title}</h3>
                  <p className={styles.featureDesc}>{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section 
        id="demo" 
        className={`${styles.section} ${visible.demo ? styles.visible : ''}`}
      >
        <div className={styles.sectionContent}>
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>See It In Action</h2>
            <div className={styles.sectionDivider}></div>
            <p className={styles.sectionSubtitle}>
              Experience the power of KageAI firsthand
            </p>
          </div>
          
          <div className={styles.demoContainer}>
            <div className={styles.demoGlow}></div>
            <div className={styles.demoContent}>
              <div className={styles.demoVideo}>
                🎬
              </div>
              <div style={{ textAlign: 'center', marginTop: '2rem' }}>
                <button 
                  className={styles.ctaPrimary}
                  onClick={() => navigate('/kageai/chat')}
                >
                  <span style={{ position: 'relative', zIndex: 10, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    Launch Interactive Demo
                    <Play size={20} />
                  </span>
                  <div className={styles.ctaPrimaryOverlay}></div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={styles.footer}>
        <div className={styles.footerContent}>
          <div className={styles.footerLogo}>KAGELABS</div>
          
          <nav className={styles.footerNav}>
            <a href="#home" className={styles.footerLink} onClick={(e) => handleSmoothScroll(e, 'home')}>Home</a>
            <a href="#features" className={styles.footerLink} onClick={(e) => handleSmoothScroll(e, 'features')}>Features</a>
            <a href="#demo" className={styles.footerLink} onClick={(e) => handleSmoothScroll(e, 'demo')}>Demo</a>
            <a href="/" className={styles.footerLink}>KageLabs</a>
          </nav>
          
          <div className={styles.footerCopyright}>
            © {new Date().getFullYear()} KageLabs. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default KageAI;