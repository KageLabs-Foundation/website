import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen, Brain, Target, Clock, Award, TrendingUp,
  Calendar, CheckCircle, Star, Menu, X, Home, Settings,
  LogOut, Plus, Play, BarChart3, Users, Moon, Sun, Search,
  Filter, ArrowRight, Zap, Trophy, ChevronRight, Grid3x3
} from 'lucide-react';
import { ThemeContext } from '../../../App';
import styles from './Dashboard.module.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Sample Data
  const stats = [
    { Icon: BookOpen, label: 'Courses Active', value: '8', change: '+2 this week', color: 'orange' },
    { Icon: Clock, label: 'Study Hours', value: '47.5', change: '+12.3 this week', color: 'blue' },
    { Icon: Target, label: 'Goals Completed', value: '23/30', change: '77% complete', color: 'green' },
    { Icon: Trophy, label: 'Achievements', value: '15', change: '3 new badges', color: 'purple' }
  ];

  const courses = [
    {
      id: 1,
      title: 'Advanced Mathematics',
      progress: 65,
      lessons: 45,
      completed: 29,
      nextLesson: 'Calculus II - Integration',
      image: '📐',
      color: 'blue'
    },
    {
      id: 2,
      title: 'Physics Fundamentals',
      progress: 42,
      lessons: 38,
      completed: 16,
      nextLesson: 'Quantum Mechanics Intro',
      image: '⚛️',
      color: 'purple'
    },
    {
      id: 3,
      title: 'Web Development',
      progress: 88,
      lessons: 52,
      completed: 46,
      nextLesson: 'React State Management',
      image: '💻',
      color: 'cyan'
    },
    {
      id: 4,
      title: 'English Literature',
      progress: 34,
      lessons: 30,
      completed: 10,
      nextLesson: 'Shakespeare Analysis',
      image: '📚',
      color: 'green'
    }
  ];

  const recentActivity = [
    { type: 'completed', text: 'Completed "Linear Algebra Chapter 5"', time: '2 hours ago', Icon: CheckCircle },
    { type: 'achievement', text: 'Earned "Study Streak" badge', time: '5 hours ago', Icon: Award },
    { type: 'study', text: 'Studied Physics for 1.5 hours', time: 'Yesterday', Icon: Brain },
    { type: 'goal', text: 'Reached weekly study goal', time: '2 days ago', Icon: Target }
  ];

  const upcomingTasks = [
    { title: 'Math Quiz - Chapter 6', due: 'Tomorrow, 2:00 PM', priority: 'high' },
    { title: 'Physics Lab Report', due: 'Dec 28, 5:00 PM', priority: 'medium' },
    { title: 'Literature Essay Draft', due: 'Dec 30, 11:59 PM', priority: 'low' },
    { title: 'Web Dev Project Review', due: 'Jan 2, 3:00 PM', priority: 'medium' }
  ];

  const studyStreak = {
    current: 12,
    longest: 28,
    thisWeek: [true, true, true, false, true, true, true]
  };

  return (
    <div className={styles.container}>
      {/* Sidebar */}
      <aside className={`${styles.sidebar} ${sidebarCollapsed ? styles.collapsed : ''}`}>
        <div className={styles.sidebarHeader}>
          <div className={styles.logo}>
            <BookOpen size={28} />
            {!sidebarCollapsed && <span>KageStudy</span>}
          </div>
          <button 
            className={styles.sidebarToggle}
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {sidebarCollapsed ? <Menu size={20} /> : <X size={20} />}
          </button>
        </div>

        <nav className={styles.sidebarNav}>
          <button 
            className={`${styles.navItem} ${activeTab === 'overview' ? styles.active : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <Grid3x3 size={20} />
            {!sidebarCollapsed && <span>Overview</span>}
          </button>
          <button 
            className={`${styles.navItem} ${activeTab === 'courses' ? styles.active : ''}`}
            onClick={() => setActiveTab('courses')}
          >
            <BookOpen size={20} />
            {!sidebarCollapsed && <span>My Courses</span>}
          </button>
          <button 
            className={`${styles.navItem} ${activeTab === 'progress' ? styles.active : ''}`}
            onClick={() => setActiveTab('progress')}
          >
            <BarChart3 size={20} />
            {!sidebarCollapsed && <span>Progress</span>}
          </button>
          <button 
            className={`${styles.navItem} ${activeTab === 'community' ? styles.active : ''}`}
            onClick={() => setActiveTab('community')}
          >
            <Users size={20} />
            {!sidebarCollapsed && <span>Community</span>}
          </button>
        </nav>

        <div className={styles.sidebarFooter}>
          <button className={styles.navItem}>
            <Settings size={20} />
            {!sidebarCollapsed && <span>Settings</span>}
          </button>
          <button className={styles.navItem} onClick={() => navigate('/kagestudy')}>
            <Home size={20} />
            {!sidebarCollapsed && <span>Back to Home</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={styles.mainContent}>
        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>Dashboard</h1>
            <p className={styles.pageSubtitle}>Welcome back, Student! 👋</p>
          </div>

          <div className={styles.topBarRight}>
            <div className={styles.searchBox}>
              <Search size={18} />
              <input 
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <button className={styles.themeToggle} onClick={toggleTheme}>
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <section className={styles.statsGrid}>
          {stats.map((stat, idx) => (
            <div key={idx} className={styles.statCard}>
              <div className={`${styles.statIcon} ${styles[`statIcon${stat.color}`]}`}>
                <stat.Icon size={24} />
              </div>
              <div className={styles.statContent}>
                <div className={styles.statLabel}>{stat.label}</div>
                <div className={styles.statValue}>{stat.value}</div>
                <div className={styles.statChange}>{stat.change}</div>
              </div>
            </div>
          ))}
        </section>

        {/* Study Streak */}
        <section className={styles.streakSection}>
          <div className={styles.streakCard}>
            <div className={styles.streakHeader}>
              <div className={styles.streakTitle}>
                <Zap size={24} />
                <span>Study Streak</span>
              </div>
              <div className={styles.streakStats}>
                <div className={styles.streakStat}>
                  <span className={styles.streakNumber}>{studyStreak.current}</span>
                  <span className={styles.streakLabel}>Current</span>
                </div>
                <div className={styles.streakStat}>
                  <span className={styles.streakNumber}>{studyStreak.longest}</span>
                  <span className={styles.streakLabel}>Longest</span>
                </div>
              </div>
            </div>
            <div className={styles.streakDays}>
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => (
                <div key={idx} className={styles.streakDay}>
                  <div className={`${styles.streakDot} ${studyStreak.thisWeek[idx] ? styles.active : ''}`}></div>
                  <span>{day}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Main Grid */}
        <div className={styles.mainGrid}>
          {/* Courses Section */}
          <section className={styles.coursesSection}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Active Courses</h2>
              <button className={styles.sectionAction}>
                View All <ChevronRight size={18} />
              </button>
            </div>

            <div className={styles.coursesGrid}>
              {courses.map((course) => (
                <div key={course.id} className={styles.courseCard}>
                  <div className={styles.courseHeader}>
                    <div className={styles.courseImage}>{course.image}</div>
                    <div className={styles.courseInfo}>
                      <h3 className={styles.courseTitle}>{course.title}</h3>
                      <p className={styles.courseProgress}>
                        {course.completed}/{course.lessons} lessons
                      </p>
                    </div>
                  </div>

                  <div className={styles.progressBar}>
                    <div 
                      className={`${styles.progressFill} ${styles[`progress${course.color}`]}`}
                      style={{ width: `${course.progress}%` }}
                    ></div>
                  </div>
                  <div className={styles.progressText}>{course.progress}% complete</div>

                  <div className={styles.nextLesson}>
                    <Play size={16} />
                    <span>{course.nextLesson}</span>
                  </div>

                  <button className={styles.continueBtn}>
                    Continue Learning
                    <ArrowRight size={18} />
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Sidebar Content */}
          <aside className={styles.sideContent}>
            {/* Upcoming Tasks */}
            <section className={styles.tasksSection}>
              <div className={styles.sectionHeader}>
                <h3 className={styles.sectionTitle}>Upcoming Tasks</h3>
                <button className={styles.iconBtn}>
                  <Plus size={18} />
                </button>
              </div>

              <div className={styles.tasksList}>
                {upcomingTasks.map((task, idx) => (
                  <div key={idx} className={styles.taskItem}>
                    <div 
                      className={`${styles.taskPriority} ${styles[`priority${task.priority}`]}`}
                    ></div>
                    <div className={styles.taskContent}>
                      <div className={styles.taskTitle}>{task.title}</div>
                      <div className={styles.taskDue}>
                        <Calendar size={14} />
                        {task.due}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Recent Activity */}
            <section className={styles.activitySection}>
              <div className={styles.sectionHeader}>
                <h3 className={styles.sectionTitle}>Recent Activity</h3>
              </div>

              <div className={styles.activityList}>
                {recentActivity.map((activity, idx) => (
                  <div key={idx} className={styles.activityItem}>
                    <div className={`${styles.activityIcon} ${styles[`activity${activity.type}`]}`}>
                      <activity.Icon size={16} />
                    </div>
                    <div className={styles.activityContent}>
                      <div className={styles.activityText}>{activity.text}</div>
                      <div className={styles.activityTime}>{activity.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;