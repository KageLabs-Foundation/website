import React from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './Tools.module.css';

const tools = [
  { id: 'chat', title: 'AI Study Chat', desc: 'Ask doubts, get explanations', icon: '💬' },
  { id: 'notes', title: 'Notes Generator', desc: 'Clean structured notes', icon: '📝' },
  { id: 'summarizer', title: 'Summarizer', desc: 'Shorten chapters & PDFs', icon: '✂️' },
  { id: 'flashcards', title: 'Flashcards', desc: 'Smart revision cards', icon: '🧠' },
  { id: 'planner', title: 'Study Planner', desc: 'Daily & weekly plans', icon: '📅' },
  { id: 'exam', title: 'Exam Mode', desc: 'Strict exam answers only', icon: '🧪' }
];

const ToolsHome = () => {
  const navigate = useNavigate();

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>AI Study Tools</h1>

      <div className={styles.grid}>
        {tools.map(tool => (
          <div key={tool.id} className={styles.card}>
            <div className={styles.icon}>{tool.icon}</div>
            <h3>{tool.title}</h3>
            <p>{tool.desc}</p>
            <button onClick={() => navigate(`/kagestudy/tools/${tool.id}`)}>
              Open →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolsHome;
