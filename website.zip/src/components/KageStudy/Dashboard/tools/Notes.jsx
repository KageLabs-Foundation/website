const Notes = () => (
  <div className={styles.toolPage}>
    <h2>Notes Generator</h2>
    <textarea placeholder="Enter topic or chapter name..." />
    <button>Generate Notes</button>
  </div>
);
export default Notes;
