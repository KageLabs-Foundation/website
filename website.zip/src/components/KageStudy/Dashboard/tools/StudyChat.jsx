import React, { useState } from 'react';
import styles from './Tools.module.css';

const Chat = () => {
  const [input, setInput] = useState('');

  return (
    <div className={styles.toolPage}>
      <h2>AI Study Chat</h2>

      <div className={styles.chatBox}>
        <div className={styles.botMsg}>
          👋 Ask me anything related to your studies.
        </div>
      </div>

      <div className={styles.inputBar}>
        <input
          placeholder="Ask a question..."
          value={input}
          onChange={e => setInput(e.target.value)}
        />
        <button>Send</button>
      </div>
    </div>
  );
};

export default StudyChat;
