const Flashcards = () => (
  <div className={styles.toolPage}>
    <h2>Flashcards</h2>
    <button>Generate Flashcards</button>
  </div>
);
export default Flashcards;
