const Summarizer = () => (
  <div className={styles.toolPage}>
    <h2>Summarizer</h2>
    <textarea placeholder="Paste text here..." />
    <button>Summarize</button>
  </div>
);
export default Summarizer;
