const Exam = () => (
  <div className={styles.toolPage}>
    <h2>Exam Mode</h2>
    <p>⚠️ Answers will be strict, concise & exam-oriented.</p>
    <textarea placeholder="Enter exam question..." />
    <button>Answer</button>
  </div>
);
export default Exam;
